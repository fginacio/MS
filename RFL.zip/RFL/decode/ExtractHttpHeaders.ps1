$p =  $args[0]
#$p = "A:\_Casedata\NetTrace\NetTrace.etl"
Out-File -InputObject $p -FilePath "$env:TEMP\ProcessEtl.txt"

If ($p -eq $null ) {
    $newext="etl"
    $newverb = "ExtractHttpHeaders"
    If ((Test-Path "HKCU:\Software\Classes\.$newext") -eq $false) {
        New-Item -Path HKCU:\Software\Classes\.$newext -Force | Out-Null
        Set-Item -Path "HKCU:\Software\Classes\.$newext\" -Value $('$newext_file') -Force
        }
    $ext_root = (Get-ItemProperty -Path "HKCU:\Software\Classes\.$newext\").'(default)'
    New-Item -Path HKCU:\Software\Classes\$ext_root -Force | Out-Null
    New-Item -Path HKCU:\Software\Classes\$ext_root\shell -Force | Out-Null
    New-Item -Path HKCU:\Software\Classes\$ext_root\shell\$newverb\ -Force | Out-Null
    $shellroot = New-Item -Path HKCU:\Software\Classes\$ext_root\shell\$newverb\command\ -Force | Out-Null
    Set-Item -Path "HKCU:\Software\Classes\$ext_root\shell\$newverb\command\" -Value $('C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -file "' + $PSCommandPath + '" "%1" ') -Force

    If ((Test-Path "HKCU:\Software\Classes\SystemFileAssociations") -eq $false) {
        New-Item -Path HKCU:\Software\Classes\SystemFileAssociations\ -Force | Out-Null
        }
    If ((Test-Path "HKCU:\Software\Classes\SystemFileAssociations\.$newext") -eq $false) {
        New-Item -Path HKCU:\Software\Classes\SystemFileAssociations\.$newext -Force | Out-Null
        New-Item -Path HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell -Force | Out-Null
    }
    If ((Test-Path "HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell\\$newverb") -eq $false) {
        New-Item -Path HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell\$newverb\ -Force | Out-Null
        Set-Item -Path "HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell\$newverb\" -Value $('Extract HTTP Headers') -Force
        $shellroot = New-Item -Path HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell\$newverb\command\ -Force | Out-Null
        Set-Item -Path "HKCU:\Software\Classes\SystemFileAssociations\.$newext\shell\$newverb\command\" -Value $('C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -file "' + $PSCommandPath + '" "%1" ') -Force
        }
Exit
}


If (Test-Path "$p") {

    Rename-Item $p $p-tmp.etl    

    # Correlate and then convert winhttp/webio into text log
    Start-Process "netsh.exe" -ArgumentList "trace correlate input=""$p-tmp.etl"" output=""$p"" overwrite=yes" -PassThru -NoNewWindow | Wait-Process
    Start-Process "netsh.exe" -ArgumentList "trace convert input=""$p"" output=""$p-formatted.log"" dump=TXT overwrite=yes" -PassThru -NoNewWindow | Wait-Process
    
    # Pull out the HTTP send/receive headers from the log
    # Filter out the send/receive HTTP headers for WinInet and WinHttp traffic
    # Only grab the Line (_.Line) member from the MatchInfo objects returned and write to file.

    Select-String -path "$p-formatted.log" -Pattern "Sending Headers|Received Headers|HTTP Request Headers|HTTP Response Headers" -AllMatches | %{$_.Line.Replace("  ","`r`t").Replace("RequestHandle","`rRequestHandle")} | Out-File "$p-HEADERS.log"
    Select-String -path "$p-formatted.log" -Pattern "HTTP Request Headers OptionalData" -AllMatches | %{$_.Line.Remove(0,127) + "`n"} | Out-File "$p-OptionalData.log"

    Remove-Item "$p-tmp.etl"

}

