# ******************************************* RFL ***********************************************
# File: Utils_RflShared.ps1
# Version 1.0
# Date: 2023-01-07
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 
# ***********************************************************************************************


##########################
## Set Variables        ##
##########################
$verDatePsm1 = "2023.01.23.0"
#$ComputerName = $Env:computername
#$UserOSVersion = [Environment]::OSVersion.Version

##########################
## Function Definitions ##
##########################

#region Logging functions
Function RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}
Function RflEnterFuncDbg([String]$FunctionName){	# enter with callstack info
	$CallStack = Get-PSCallStack
	$CallerInfo = $CallStack[1]
	$2ndCallerInfo = $CallStack[$Index+1]
	$3rdCallerInfo = $CallStack[$Index+2]
#write-host "1-2-3: $CallerInfo $2ndCallerInfo $3ndCallerInfo"
	# LogMessage() is called from wrapper function like LogInfo() and EnterFunc(). In this case, we show caller of the wrapper function.
	If($CallerInfo.FunctionName -notlike "*LogException" -and ($CallerInfo.FunctionName -like "global:Log*" -or $CallerInfo.FunctionName -like "*EnterFunc*" -or $CallerInfo.FunctionName -like "*EndFunc" -or $CallerInfo.FunctionName -like "DoGetVersion")){
		$CallerInfo = $2ndCallerInfo # Set actual function name calling LogInfo/LogWarn/LogError
		If($CallerInfo.FunctionName -like "*LogException"){
			$CallerInfo = $3rdCallerInfo
		}
	}
	$FuncName = $CallerInfo.FunctionName.Replace("global:","")
	If($CallerInfo.FunctionName -like '<ScriptBlock>'){ #-eq
		 $FuncName = 'Main'
	}Else{
		$FuncName = $CallerInfo.FunctionName
	}
	RflEnterFunc ("$FuncName" + " (Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
}
Function RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
}

Function WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}

Function ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[Update] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		}
}
#endregion Logging functions

#region RFL functions
function GetOSfromMSinfo32 ($SDPPath,$NodeName){
	# Return: $OSshortVer of SDP report
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "[GetOSfromMSinfo32]** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "[GetOSfromMSinfo32]Node: $NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "[GetOSfromMSinfo32]msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-host "`n[GetOSfromMSinfo32]Node: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		$msinfo32[-7]
				$global:SdpOSname = 		$msinfo32[-8];$SdpOSname=$global:SdpOSname.Split(" ",3)[2]
				$global:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$Systemmodell = 	$msinfo32[-2] #.Split("")[1,2,3]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$msinfo32[-1] #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				#_#Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
				Write-Host " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$global:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$SdpOSbuild = 		$summary.'#cdata-section'[1]
				$global:SdpOSname = 		$summary.'#cdata-section'[0]
				$global:SdpComputerName = 	$summary.'#cdata-section'[4]
				$Systemmodell = 	$summary.'#cdata-section'[6]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$summary.'#cdata-section'[7]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$global:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$global:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$OSshortVer_old="old-XP"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$OSshortVer_old="old-2003"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$OSshortVer_old="old-2008-SP1"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$OSshortVer="2008"}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$OSshortVer_old="old-2008R2-RTM"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$OSshortVer="2008R2"} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$OSshortVer="2012"}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$OSshortVer="2012R2"} 			# Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$OSshortVer="2016"} 		# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$OSshortVer="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$OSshortVer="2016RS5"} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "10.0.18363"){$OSshortVer="201619H2"}	# Windows 10 19H2
	if("$SdpOSbuild" -match "10.0.19041"){$OSshortVer="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$OSshortVer="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$OSshortVer="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$OSshortVer="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$OSshortVer="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$OSshortVer="2022"} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.22000"){$OSshortVer="Win11"} 		# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$OSshortVer="Win1122H2"}	# Windows 11 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.22622"){$OSshortVer="Win1123H1"}	# Windows 11 insider
	Write-Host " OS build: $SdpOSbuild -|OS: $OSshortVer $OSshortVer_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($OSshortVer) $($OSshortVer_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
	
	$OSshortVer	# return
	RflEndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $OSVersion $OSVersion_old)")
}

#endregion RFL functions

# only for module .psm1
#Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *



# SIG # Begin signature block
# MIInpwYJKoZIhvcNAQcCoIInmDCCJ5QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtbTtXjZ0WtpIZ
# nAoNss/cAT7l/J0HSuyKfZjLHZbl2qCCDYUwggYDMIID66ADAgECAhMzAAACzfNk
# v/jUTF1RAAAAAALNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NjAyWhcNMjMwNTExMjA0NjAyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDrIzsY62MmKrzergm7Ucnu+DuSHdgzRZVCIGi9CalFrhwtiK+3FIDzlOYbs/zz
# HwuLC3hir55wVgHoaC4liQwQ60wVyR17EZPa4BQ28C5ARlxqftdp3H8RrXWbVyvQ
# aUnBQVZM73XDyGV1oUPZGHGWtgdqtBUd60VjnFPICSf8pnFiit6hvSxH5IVWI0iO
# nfqdXYoPWUtVUMmVqW1yBX0NtbQlSHIU6hlPvo9/uqKvkjFUFA2LbC9AWQbJmH+1
# uM0l4nDSKfCqccvdI5l3zjEk9yUSUmh1IQhDFn+5SL2JmnCF0jZEZ4f5HE7ykDP+
# oiA3Q+fhKCseg+0aEHi+DRPZAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU0WymH4CP7s1+yQktEwbcLQuR9Zww
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ3MDUzMDAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE7LSuuNObCBWYuttxJAgilXJ92GpyV/fTiyXHZ/9LbzXs/MfKnPwRydlmA2ak0r
# GWLDFh89zAWHFI8t9JLwpd/VRoVE3+WyzTIskdbBnHbf1yjo/+0tpHlnroFJdcDS
# MIsH+T7z3ClY+6WnjSTetpg1Y/pLOLXZpZjYeXQiFwo9G5lzUcSd8YVQNPQAGICl
# 2JRSaCNlzAdIFCF5PNKoXbJtEqDcPZ8oDrM9KdO7TqUE5VqeBe6DggY1sZYnQD+/
# LWlz5D0wCriNgGQ/TWWexMwwnEqlIwfkIcNFxo0QND/6Ya9DTAUykk2SKGSPt0kL
# tHxNEn2GJvcNtfohVY/b0tuyF05eXE3cdtYZbeGoU1xQixPZAlTdtLmeFNly82uB
# VbybAZ4Ut18F//UrugVQ9UUdK1uYmc+2SdRQQCccKwXGOuYgZ1ULW2u5PyfWxzo4
# BR++53OB/tZXQpz4OkgBZeqs9YaYLFfKRlQHVtmQghFHzB5v/WFonxDVlvPxy2go
# a0u9Z+ZlIpvooZRvm6OtXxdAjMBcWBAsnBRr/Oj5s356EDdf2l/sLwLFYE61t+ME
# iNYdy0pXL6gN3DxTVf2qjJxXFkFfjjTisndudHsguEMk8mEtnvwo9fOSKT6oRHhM
# 9sZ4HTg/TTMjUljmN3mBYWAWI5ExdC1inuog0xrKmOWVMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXgwghl0AgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAALN82S/+NRMXVEAAAAA
# As0wDQYJYIZIAWUDBAIBBQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEXD
# ofni4btNVriSGXSQ/ySDNezvDZcBFB2nAsO18HtBMEQGCisGAQQBgjcCAQwxNjA0
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQu
# Y29tIDANBgkqhkiG9w0BAQEFAASCAQByG6xHwUekfQv5KMh9sYf1KlYtAazAJX7f
# Rh9yiXMrZrHk+i+LTM8pdfyFNbMYfaV5DZTCb/mZSOWqlmj5UKlAQxbAwALP2k3v
# MhjL2ax2kmIMEwT08zP+dklvpepQDAVNPjy/eVSmJwM5vc3ziUQsVqDFAiX5SIA5
# uOqxIKni862zXp1mqb2e/n8wJs2U2stmddKkQX8PVBeU+/npWme3hfpR2ciSbE5u
# 8vFEzSjnZbomsgh3TQBR7AO2uXC/3tQAw78T+iIleFqeJeJpKgnrxsXtr4YBEICO
# mwFvmOMJT29B66SqBSkPMzhdQ3f+wYpbNbSEj2u7OnRjBnLYahlooYIXADCCFvwG
# CisGAQQBgjcDAwExghbsMIIW6AYJKoZIhvcNAQcCoIIW2TCCFtUCAQMxDzANBglg
# hkgBZQMEAgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEE
# AYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIL4po/tTIfWhjatc48sYeHmNHXSyjmHh
# qctiT73Eymh8AgZjv/DYwigYEzIwMjMwMjA2MTAzNTIxLjYxNVowBIACAfSggdCk
# gc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNV
# BAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxl
# cyBUU1MgRVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBTZXJ2aWNloIIRVzCCBwwwggT0oAMCAQICEzMAAAG+9CCi7pbWINYA
# AQAAAb4wDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwHhcNMjIxMTA0MTkwMTIyWhcNMjQwMjAyMTkwMTIyWjCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTVBNi1F
# MjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQClX/LbPsNrucy7S3KQtjyi
# WHtnTcSoU3PeIWUyn2A59WZkAGaF4JzztG491DY/44dQmKoJABY241Kgj9DWLETD
# 0ADrnuV0Pxnf8SS2mbEocdq86HBBIU9ylMYVVcjEoLCg7zbiCLIc8bzh1+F2LpZT
# t/sP7zkto8HR06w8coowaUL2nrou/3JDO8CFkYWYWGW6wLL96CvPolf84c5P2oLC
# 6CGsvQg9/jtQt7WlBIQSKHLjfwnBL6tlTgBXK9BzOUwLbpexO4M+ARAqXPH2u7sS
# 81X32X8oJT1tsV/lKeQ3WahSApSrT01aUrHMsYS+GR7ZA0yimfzomHV+X89V683/
# GtlKlXbesziUHuWHtdKwI94WyVNiiMo3aKg4LqncHLuQSa9kKHqsCw8qwBEkhJ3M
# pAIyr6aoO6I/qav8u+5YqKc/7ZkaYr8LX+yS+VOO0h6G7nTKhc0OWHUI30HdAuCV
# Bj5QIESomiD8HECfelZ1HTWj/rpchpyBcj93TAbb/HQ61uMQYCRpx9CWbDRsNzTZ
# 2FAWSL/VD1VvCHiQLtWACIkDxsLnMQhhYc1TsL4d7r0Hj/Z1mlGOB3mkSkdsX05i
# IB/uzkydgScc3/mj9sY7RqMBvtUjh/1q/rawLrG+EpMHlHiWHEQxYXTPi/sFDkIf
# Iw2Qv6hOfMkuqctV1ee4zQIDAQABo4IBNjCCATIwHQYDVR0OBBYEFOsqIBahhEGg
# 8a1vC9uGFfprb6KqMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# DQYJKoZIhvcNAQELBQADggIBAMeV+71zQiaF0GKzXKPnpsG85LIakL+tJK3L7UXj
# 1N/p+YUR6rGHBNMdUc54hE13yBwMtLPR3v2ZcKqrzKerqAmDLa7gvLICvYubDMVW
# 67GgZVHxi5SdG2+wMfkn66fJ7+cyTAeIL4bzaHe5Dx9waP7YfSco+ZSlS19Cu4xR
# e/MuNXk3JGMOIIvlz9/l5ybPTV2emcK8TqQjP8VOmS855UmTbYjZqQVmE/PbgPo5
# PoqRO3AFGlIQcNioJDhxn7tJfHuPPN3tv7Sn28NuioLLtLBaAqkZAb7BVsqtObiE
# qRkPNx0ASBip6FfPvwbTSZgguINPJSKTBCmhntqb2kDoF1M9j6jW/oJHNyd4g6cl
# hqcdbPRH4oRH9lEW0sLIEy8vNIcSfSxHT7SQuSWdwqMZ0DVgDjbM5vrXVR4gbK1n
# 1WE3CfjCzkYnqfo8mYw877I8SQ7LZ/w4GK6FqqWKmJaHMa23lSwLSB4bSxb2rBrh
# ABbWxBYiuFKXbgw45XA2X8Cb39mq8tFavXHie6l5Hwbv4M3KfgxODbzIVlFTWS1K
# /IExRK83Yr30E7qnWBLH/C9KxHjl0bfc8Mbl8qoc6APFy2MFTltfj14mqM0vtL9S
# d0sXtLQ5Yv2Z2T+M9Uc/Yjpe03QrhWN1HC8iCveM2JvcZnIYmc5Gn9kxtjYO/WYp
# zHt1MIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOTh
# pkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xP
# x2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ
# 3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOt
# gFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYt
# cI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXA
# hjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0S
# idb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSC
# D/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEB
# c8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh
# 8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8Fdsa
# N8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkr
# BgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q
# /y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBR
# BgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAP
# BgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjE
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEB
# CwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnX
# wnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOw
# Bb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jf
# ZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ
# 5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+
# ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgs
# sU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6
# OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p
# /cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6
# TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784
# cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAs4wggI3
# AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYD
# VQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUyN0MtNTkyRTElMCMGA1UEAxMcTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAaK1aUve8
# +7wQ04B76Lb7jB9MwHuggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDANBgkqhkiG9w0BAQUFAAIFAOeKu2wwIhgPMjAyMzAyMDYwNzM0MDRaGA8y
# MDIzMDIwNzA3MzQwNFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA54q7bAIBADAK
# AgEAAgIUUQIB/zAHAgEAAgIRRjAKAgUA54wM7AIBADA2BgorBgEEAYRZCgQCMSgw
# JjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3
# DQEBBQUAA4GBAJlNQRvUQJr+lQiTfEB2j0PLEeUFNhpdItpW4w6/gWdwL79G/tKu
# OnGW9vh27uGalfaBgWbCKorANE5Azx3AhbY9zo10p87ML1yqmNrZM19XI0afI3N0
# UoL7+X1HPRLCCDejLlPCLfFWLVqUcvuO6JbJ8aULLVbECIpL/uOkWMF6MYIEDTCC
# BAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAG+9CCi
# 7pbWINYAAQAAAb4wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsq
# hkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgnK50Y0aKdfrLkLGs8DDSljs577HA
# VPca4Y3eKTttfsIwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCU7oqvrfb8
# 7L1ltc+uEQ+J00CD8V5/srdJmD4PGOEMLzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFBDQSAyMDEwAhMzAAABvvQgou6W1iDWAAEAAAG+MCIEIJTNnsrYbwnE
# MBSFtr6tnXAW/qHNwnsR4M0m2Z7kUtZYMA0GCSqGSIb3DQEBCwUABIICAHPZ+RZo
# 5CDIc5xON5Elon84qyp1/qHh5XJv5k3ZC4qyikuw1KsfmW1As2i5ysSSw+CB9pu3
# +Z6leh32NgZ9+nQ1k+9Njc3LXl46GjeT7F6UpyxlgYOWznDoZZymE+KUEnisaVLC
# DAxaG0xqXaxDRcF4kDm6rR9twS8N8pPWGBwFmqOliMwaMlWgNNqGCtVj/7s5zGSJ
# kz0lmsoNAznUjnn69a5WIU+LPcTEibQ2MSFMO9UmGoFzB+wjCddSNVA4jR+Y9aHl
# lwseWBgnkVsfZ7942QM1Y6EYfGheyZNgFWaNTJVgC2VYxagjrNjfs7wSlSYXtUMs
# nMwTiB55FHAhR7/HUYxHqDKo3Sa8W6EaRwPMhGKKcAh0HHZ0cu3Nok3ohbyaX8vG
# cD6CIkR+i52RUOKWLSWvOch1dkiiHZWLQzMVNa0GB9LfEi88GzAfvcyuSW+U7HIp
# hMutJHLlhvzlczvSkbXgSrTefbfwW+UlrQL5RwTygMIt0oF8+wnzfM6/nuod117u
# WjkiZuwXkdpXAIP0ENrOPPn03QESQlGuzsfyokOqQZ/xRp8JBXWqaWpCFOHvw1an
# MnRdc+ho7qV9zZ+1ny5JbTgBzJEKOlQGZPeP1XvZ7Xo23i0WGVQrhoXF3+hag8pS
# sv0FqnUwWDLwntQlcEWiZ+Y63EeuLLvuzjpg
# SIG # End signature block
