# Name: RFL_update-script.ps1 forSDPcheck in OfflineMode
# last edit by: waltere 2023-01-08

<# 
.SYNOPSIS
	For offline-SDPcheck: Script to [auto-]update RFL to latest version or download latest RFL.zip from CesdiagTools/GitHub.

.DESCRIPTION
	For offline-SDPcheck: Script will search on "https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag" / GitHub for latest RFL version
	If local version does not match the remote CesdiagTools/GitHub version, it will download and replace RFL with latest version
	Script gets the current version from _SDPcheck.ini and compares to version on 'https://cesdiagtools.blob.core.windows.net/windows/RFL.ver' /GitHub.

.PARAMETER RFL_action
	choose action from allowed values: "Download" or "Update" or "Version"
		Download	= download latest CesdiagTools/GitHub version
		Update		= update current local version
		Version		= decide based on local version, try AutoUpdate if local version is lower than CesdiagTools/GitHub version
	Ex: -RFL_action "Download"

.PARAMETER RFL_file
	Specify filename from allowed values: "RFL.zip" or "RFL_DB.zip"
	Ex: .\RFL_update-script.ps1 -RFL_file "RFL.zip"

.PARAMETER RFL_path
	Specify the local path where check-rfl-csv_Tech_Path.ps1 is located.
	Ex: .\RFL_update-script.ps1 -RFL_path "C:\RFL"

.PARAMETER UpdMode
	Specify the mode: 
		Online  = complete package (RFL.zip) from aka.ms/getRFL
		Full    = complete package (RFL.zip) from CesdiagTools/GitHub
		Quick   = differential package only (RFL_DB.zip): replace only database files
		Force   = run a Full update, regardless of current installed version

.PARAMETER RFL_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: .\RFL_update-script.ps1 -RFL_arch "x64"

.EXAMPLE
	Example 1: Update RFL in folder C:\RFL
	.\RFL_update-script.ps1 -RFL_action "Update" -RFL_path "C:\RFL" -RFL_file "RFL.zip"

.LINK
	https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag
	Public Download: RFL:    https://cesdiagtools.blob.core.windows.net/windows/RFL.zip -or- https://aka.ms/getRFL or aka.ms/getRFL
#>


[CmdletBinding()]
PARAM (
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$RFL_action 	= "update",
	[string]$RFL_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("Online","Full","Quick","Force")]
	[string]$UpdMode 		= "Full",
	[ValidateSet("RFL.zip","RFL_DB.zip")]
	[string]$RFL_file 		= "RFL.zip",
	[ValidateSet("x64","x86")]
	[string]$RFL_arch 		= "x64",
	[switch]$AutoUpd		= $False,							# 
	[switch]$UseExitCode 	= $true								# This will cause the script to bail out after the error is logged if an error occurs.
)

#region  ::::: [Variables] -----------------------------------------------------------#
$verDateScript	= "2023.02.09.0"
$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent

$script:ChkFailed	= $FALSE
$invocation 		= (Get-Variable MyInvocation).Value
$ScriptParentPath 	= $MyInvocation.MyCommand.Path | Split-Path -Parent
$scriptName 		= $invocation.MyCommand.Name
if ($UpdMode -match 'Online') {
	$RflUpdLogfile 		= $env:TEMP + "\_RFL_Update-Log.txt"
	$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$RFL_release_url  = "https://cesdiagtools.blob.core.windows.net/windows"
} else {
	$RflUpdLogfile 		= $ScriptFolder + "\_RFL_Update-Log.txt"
	$RFLReleaseServer = "api.Github.com"
	$RFL_release_url  = "https://api.github.com/repos/walter-1/offline-SDPcheck/releases"
}
#endregion  ::::: [Variables] --------------------------------------------------------#
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1
	  
$Script:BeginTimeStamp = Get-Date


# Check if trailing "\" was provided in $RFL_path, if it was not, add it
if (-not $RFL_path.EndsWith("\")){
	$RFL_path = $RFL_path + "\"
}

#region  ::::: [MAIN] ----------------------------------------------------------------#
	# detect OS version and SKU # Note: gwmi / Get-WmiObject is no more supportd in PS v7 -> use Get-CimInstance
	If($Host.Version.Major -ge 7){
		[Reflection.Assembly]::LoadWithPartialName("System.ServiceProcess.servicecontroller") | Out-Null
		$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
	} else {$wmiOSVersion = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem}
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	#Write-verbose "installed-version: $(get_local_RFL_version current) - Build: $bn"
	$installedRFLver = New-Object System.Version([version]$(get_local_RFL_version "current"))
	Write-verbose "installedRFLver: $installedRFLver"

	## :: Criteria to use Quick (DB only) vs. Online update: Quick if UpdMode = Quick; Online = if full package is needed, ...
	# Choose download file based on $UpdMode (and current installed RFL build)
	$RFL_file = "RFL.zip"
	switch ($UpdMode) {
			"Quick"	{ 	$RFL_file = "RFL_DB.zip"
						$UpdateSource= "GitHub"}
			"Online"{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "CesdiagTools"}
			default	{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "GitHub"}
	}
			
	# Check for Internet connectivity // Test-NetConnection does not work for Win7
	$isReachable = FwTestConnWebSite $RFLReleaseServer -ErrorAction SilentlyContinue
	if ( $isReachable -eq "True") {
		if ($UpdMode -Notmatch "Online") {
			$script:expectedVersion = New-Object System.Version(get_latest_RFL_version $RFL_release_url)
		}
		if ("$($script:expectedVersion)" -eq "0.0") { Write-Verbose "Bail out: $script:expectedVersion"; ExitWithCode 20}
		# Check if RFL exists in $RFL_path
		if (-not (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1"))){
			Write-Host -ForegroundColor Red "[Warning] check-rfl-csv_Tech_Path.ps1 could not be located in $RFL_path"
			DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
		}

		if (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1")){
			if ($UpdMode -match "Online") {
				DownloadRFLZipFromCesdiagRelease -File "RFL.zip"
			}
			elseif ($UpdMode -match "Force") {	# update regardless of current local version
			Write-Host -ForegroundColor Cyan "[Forced update:] to latest version $script:expectedVersion from $UpdateSource`n"
			 if (Test-Path ($RFL_path + "x64\TTTracer.exe")) { Write-Host -ForegroundColor Yellow "[note:] This procedure will not refresh iDNA part"}
										DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
			} else {
				Write-Host "[Info] checking current version $installedRFLver in $RFL_path against latest released $UpdateSource version $script:expectedVersion."
				if ($($installedRFLver.CompareTo($script:expectedVersion)) -eq 0) { 		# If versions match, display message
					"`n [Info] Latest RFL version $script:expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor Cyan "[Info] Latest RFL version $script:expectedVersion is installed.`n"}
				elseif ($($installedRFLver.CompareTo($script:expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
					"`n [Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated] " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor red "[Warning] Actually installed RFL version $installedRFLver is outdated"
					Write-Host "[Info] Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
					Write-Host -ForegroundColor yellow "[Warning] ** Update will overwrite customized Shell script, latest Rfl-Check_ShellExtension.reg is preserved in Rfl-Check_ShellExtension.reg_backup. ** "
					switch($RFL_action)
						{
						"download"		{ 	Write-Host "[download:] latest $RFL_file"
											DownloadFileFromGitHubRelease "download" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"update"		{ 	Write-Host "[update:] to latest version $script:expectedVersion from $UpdateSource " 
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"version"		{ 	Write-Host -background darkRed "[version:] installed RFL version is outdated, please run 'RFL Update', trying AutoUpate" # or answer next question with 'Yes'"
											Write-Host -ForegroundColor Cyan "[Info] running AutoUpdate now... (to avoid updates, append RFL switch 'noUpdate')"
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						}
					"`n [Action: $RFL_action - OK] " | Out-File $RflUpdLogfile -Append
				}
				else {	# if installed current version is greater than latest CesdiagTools/GitHub Release version
					if ($script:ChkFailed) {Write-Host -ForegroundColor Gray "[Info] Version check failed! Expected version on $($UpdateSource) = $script:expectedVersion. Please download https://aka.ms/getRFL `n"}
					Write-Verbose "Match: Current installed RFL version:  $installedRFLver"
					Write-Verbose "Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
				}
			}
		}
	} else {
		Write-Host -ForegroundColor Red "[failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n"
									 "`n [failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n" | Out-File $RflUpdLogfile -Append
	}

	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp)

	Write-Host -ForegroundColor Black -background gray "[Info] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if ($AutoUpd) { Write-Host -ForegroundColor Yellow  "[AutoUpdate done] .. Please repeat your RFL command now."}
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 

- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "RFL Updater" /TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "RFL Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] ----------------------------------------------------------------#



# SIG # Begin signature block
# MIInpAYJKoZIhvcNAQcCoIInlTCCJ5ECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAVNdlFs26K9uu7
# D2z4YmkqNUtiQXNMWyMHKNAcoHXUAKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYQwghmAAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMAy5fKHIv172mlGNwTRed2V
# VicFBk8R6qiex0HJS799MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQA42r/sHiklSpvxuEHgMbGrfNYehUpxMSpZoNlrj2d68CIDNLqGYfxr
# sXVB+kIt/7aIp/6hWueI3xn/sHwtSiUEaLhcILF6rBNvYpk2QkytMKCdFyWEhpWA
# MqqGN+nXjpaCGUU4gAbKn51HYcl5M9wuAbnSbBIe7VLrm8psvAi39a2evGvrN6px
# wxPgpT67WOaMbM9V+Hony+SGFBtSfDRd1fxuS6ZWQtIpg6HXMSO4FAitGNHhHo2Q
# iwAaN1/eqvKnVJ1jGF6/2ENNxbLOgfOalY+wrkn058Sv6MfLcTz1yOxKtlrF/c6g
# aHOrSoV31WPlAmfeKTax4P96IH1p5k9ioYIXDDCCFwgGCisGAQQBgjcDAwExghb4
# MIIW9AYJKoZIhvcNAQcCoIIW5TCCFuECAQMxDzANBglghkgBZQMEAgEFADCCAVUG
# CyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEINq1yerWzADiUdnznbETpVHMjfy4FrJFl4G4RbLqiol8AgZjxxZf
# wVsYEzIwMjMwMjEwMDgwNjA1LjE5MlowBIACAfSggdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2
# MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaCCEV8wggcQMIIE+KADAgECAhMzAAABpllFgzlNnutLAAEAAAGmMA0GCSqG
# SIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMDMw
# MjE4NTEyMVoXDTIzMDUxMTE4NTEyMVowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2MEJDLUUzODMtMjYz
# NTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJ
# KoZIhvcNAQEBBQADggIPADCCAgoCggIBANmYv3tSI+fJ/NQJnjz7JvCnc+Xm0rKo
# e9YKD4MvMYCul7egdrT/zv5vFbQgjNQ74672fNweaztkR65V8y29u5PL2sf01p+u
# che0Zu4tSig+GsQ6ZQl9tjPRAY/3ITBHDeIYyvq8Wne9+7NoPLhxDSO6dtX7YCuQ
# 4zcTP3SE6MvB4b5NighdtvoZVaYk1lXpjUTfdmKoX1ABq1sJbULSnSi0Qd4vvl3m
# Z9jxwv9dR/nlZP62lrZYZq7LPtHD6BlmclB5PT89DnSm1sjaZnFHrKzOsmq5GlmL
# 5SFugCCZOoKz133FJeQaFMcXBZSCQjNABWBbHIRCE1ysHHG83DdonRmnC8EOlYeR
# wTWz/QCz6q0riOIbYyC/A2BgUEpu9/9EymrTsyMr2/zS8GdEybQ5W7f0WrcrmKB/
# Y62+g6TmfOS8NtU+L1jGoKNG6Q5RlfJwZu8J/Q9dl4OxyHKuy78+wm6HsF7uAizp
# sWh63UUaoK/OGQiBG3NJ+kef5eWpnva4ZJfhAnqYTAZD1uHgf8VfQjnl0BB2YXzK
# 9WaTqde8d+8qCxVKr5hJYvbO+X3+2k5PCirUK/SboreX+xUhVaQEhVDYqlatyPtt
# I7Z2IrkhMzwFvc+p0QeyMiNmo2cBZejx8icDOcUidwymDUYqGPE7MA8vtKW3feeS
# SYJsCEkuUO/vAgMBAAGjggE2MIIBMjAdBgNVHQ4EFgQUOlQhO/zGlqK99UkNL/Gu
# /AryN9gwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgw
# VjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWlj
# cm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUF
# BwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgx
# KS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAgEAgMDxWDTpGqLnFoPhm/iDfwHGF8xr2NbrJl8egEg2ThTJsTf0
# wBE+ZQsnYfrRmXBbe6sCXLVN70qPuI+OEbN5MOai7Bue1/4j5VTkWquH5GZeVat2
# N+dD7lSUWp0dU8j+uBhBL5GFSmoDVVm+zW2GR2juPI1v254AJTb2l458anlkJjGv
# mYn2BtRS13h/wDR7hrQaI7BgdyHWAV5+HEj5UhrIrrvtwJiivSaUEA3qK6ZK/rZI
# Qv/uORDkONw+2pHHIE1SXm/WIlhrVS2HIogfr3JjqvZion6LJSD741j8xVDLiClw
# AbspHoVFjxtxBcMjqPx6aWCJS8vjSoTnhkV4PO55mqsM7Q8XQRGQhA7w4zNQOJu9
# kD4xFdYpPUmLN/daIcEElofBjGz+sEd1B4yqqIk3u2G4VygTXFmthL8chSo7r+GI
# vTqWKhSA/sanS4N3jCgCCe3FTSJsp4g5nwavLvWAtzcOIvSRorGmAeN0m2wgzBK9
# 5T/qgrGGDXSos1JNDWRVBnP0qsw1Qoq5G0D8hxvQPs3X43KBv1GJl0wo5rcC+9OM
# WxJlB63gtToQsA1CErYoYLMZtUzJL74jwZk/grpHEQhIhB3sneC8wzGKJuft7YO/
# HWCpuwdChIjynTnBh+yFGMdg3wRrIbOcw/iKmXZopMTQMOcmIeIwJAezA7Awggdx
# MIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGI
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylN
# aWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5
# MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciEL
# eaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa
# 4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxR
# MTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEByd
# Uv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi9
# 47SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJi
# ss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+
# /NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY
# 7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtco
# dgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH
# 29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94
# q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcV
# AQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0G
# A1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQB
# gjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIB
# AJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRs
# fNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6
# Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveV
# tihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKB
# GUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoy
# GtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQE
# cb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFU
# a2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+
# k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0
# +CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cir
# Ooo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIC0jCCAjsCAQEwgfyh
# gdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAn
# BgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjo2MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAanQzrZW9TB93
# Ve7Pa4UPao2ffK2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQUFAAIFAOeP5sYwIhgPMjAyMzAyMTAwMTQwMjJaGA8yMDIz
# MDIxMTAxNDAyMlowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA54/mxgIBADAKAgEA
# AgIeewIB/zAHAgEAAgIRDTAKAgUA55E4RgIBADA2BgorBgEEAYRZCgQCMSgwJjAM
# BgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEB
# BQUAA4GBAKL0e73CxQNtCWVvS4I6Snf+cJyFd4uN8NcRJARBRnea+I7E6e9MzxEQ
# nNyIiUmh+aobbtuZMYvV+Xwoe4csasyECbXVvfuTrwCBXfsC5ScRLyVf1M983qeX
# nkVrlFhGruxq0yAUplDgek7+coDrqPGohzAKKXg3sNZOP4XdBucrMYIEDTCCBAkC
# AQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGmWUWDOU2e
# 60sAAQAAAaYwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG
# 9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgAA4eSJMqCRjoCnjU+vZavh0ihCyGofLt
# En16I/SYOgwwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCDCxmLwz90fWvh
# MKbJTAQaKt3DoXeiAhfp8TD9tgSrDTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwAhMzAAABpllFgzlNnutLAAEAAAGmMCIEIKzNxw2HePGtb6w2
# koPyfEucG6gV9CNL6QGf8+/M4yidMA0GCSqGSIb3DQEBCwUABIICAFl6rLDRN2QC
# yCF+h+j62CRxDvIbTl2gEPfMbuGEwb1QCIOAyc4Jb1by0vL+4fS4FvEUuiTAtIta
# jYFUJRdI/om0GGbgWA/hGgAnulPMC6ZZdXXAy4jIy7TgDvyCYsShe4jmaRMDYYP7
# /YeHmNyR4YjPYTCTchGrWGK3sQVKGEApX/Sok0AewVDidnVwyM0RGTRvA8wVFxfM
# RzElvbS8RwJltFh+Rzv3r//vvCUcJ+XUoVX0JN8FdNR22zz7d716ySRSKEa3LuZu
# +70DjDkkGZZJBC6USuEo80hxVODqjDvcAHOzL5JcWGMuJODix6m2eE8CJRl+Jrkq
# kb1eE+tl6g/uPaenGMc6JJZiZhElH4rlvC2WFrIWO4rA1O/lxjEOKCoFVgIkl9b6
# AQEgTCNAkDDRtK5JwzT0ky6nFf01Kr18/S1t7gLNaisA7EPHLF0ESBuYlpfVBn7o
# W3WSbxlagsBjAAdsVEFI/KbVK6VTBB3p2TcGkJV3VXGNBvcp4XtzMnIvCzD7+emc
# HRVeUSxmSQkuh8TaYeWIZs/uW04bXiAqrUY+p/QL2Y+tBcH0cGoSDl9bbd7TTDqB
# ncoD1qOunblGDEiwQn9LYZxcdLdTXdPUr4Rk8wdNyn9zoOO1axz0ZC7pT504Ynt/
# MswShuijirc8bBc3Ws+aNhk8dI5EmFcW
# SIG # End signature block
